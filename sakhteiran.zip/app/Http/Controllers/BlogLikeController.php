<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogLikeController extends Controller
{
    //no need yet
}
