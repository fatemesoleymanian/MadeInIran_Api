<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogTagController extends Controller
{
    //no need yet
}
