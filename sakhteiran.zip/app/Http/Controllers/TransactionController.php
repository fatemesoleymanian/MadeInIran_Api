<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransactionController extends Controller
{
    //badaz pardakht status order va card bayad 0 she
    public function showAll()
    {

    }
    public function show()
    {

    }
    public function showAllByUser($user)
    {

    }
    public function showByOrder($order)
    {

    }
}
