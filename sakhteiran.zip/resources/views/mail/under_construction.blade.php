<div style="direction: rtl;float: right">
    <h2>اطلاعات مشتری :</h2>
<pre style="font-size: 18px;font-weight: 500">
 نام : {{$full_name}}
 شماره تماس : {{$phone_number}}
 توضیحات ایده مد نظر : {{$description}}

</pre>
</div>
