<div style="direction: rtl;float: right">
    <pre>
        کد تایید ساخت ایران : {{$code}}
    </pre>
</div>
