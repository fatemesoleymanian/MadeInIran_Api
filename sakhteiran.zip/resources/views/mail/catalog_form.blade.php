<div style="direction: rtl;float: right">
    <h2>اطلاعات فرم :</h2>
    <h6 style="font-size: 18px;font-weight: 500">نام : {{$full_name}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">شماره تماس : {{$phone_number}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">تحصیلات : {{$education}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">شهر مورد درخواست : {{$city}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">سن : {{$age}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">رشته تحصیلی : {{$course}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">سوابق شغلی : {{$work_experience}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">شغل فعلی : {{$job}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">پکیج مدنظر : {{$selected_package}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">کارشناس مربوطه : {{$experts}}</h6>
    <h6 style="font-size: 18px;font-weight: 500"> دلایل دریافت نمایندگی : {{$reasons}}</h6>
    <h6 style="font-size: 18px;font-weight: 500">  تاریخ ثبت فرم  : {{$created_at}}</h6>
</div>
