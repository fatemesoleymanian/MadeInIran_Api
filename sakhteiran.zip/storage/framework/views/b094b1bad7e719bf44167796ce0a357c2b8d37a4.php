<div style="direction: rtl;float: right">
    <pre>
        کد تایید ساخت ایران : <?php echo e($code); ?>

    </pre>
</div>
<?php /**PATH E:\My Portfolio\Freelancing\MadeInIr\sakhteiran\resources\views/mail/conf_code.blade.php ENDPATH**/ ?>