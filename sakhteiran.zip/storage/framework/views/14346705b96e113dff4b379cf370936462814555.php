<div style="direction: rtl;float: right">
    <h2>اطلاعات فرم :</h2>
    <h6 style="font-size: 18px;font-weight: 500">نام : <?php echo e($full_name); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">شماره تماس : <?php echo e($phone_number); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">تحصیلات : <?php echo e($education); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">شهر مورد درخواست : <?php echo e($city); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">سن : <?php echo e($age); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">رشته تحصیلی : <?php echo e($course); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">سوابق شغلی : <?php echo e($work_experience); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">شغل فعلی : <?php echo e($job); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">پکیج مدنظر : <?php echo e($selected_package); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">کارشناس مربوطه : <?php echo e($experts); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500"> دلایل دریافت نمایندگی : <?php echo e($reasons); ?></h6>
    <h6 style="font-size: 18px;font-weight: 500">  تاریخ ثبت فرم  : <?php echo e($created_at); ?></h6>
</div>
<?php /**PATH E:\My Portfolio\Freelancing\MadeInIr\sakhteiran\resources\views/mail/catalog_form.blade.php ENDPATH**/ ?>